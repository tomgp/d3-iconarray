# d3-iconarray

draw an array of icons!

## Installing

If you use NPM, `npm install d3-iconarray`. Otherwise, download the [latest release](https://github.com/tomgp/d3-icon-array/releases/latest).

## API Reference


<a href="#iconarray" name="iconarray">#</a> <b>iconarray</b>()
