# d3-iconarray

draw an array of icons!

## Installing

If you use NPM, `npm install d3-iconarray`. Otherwise, download the [latest release](https://github.com/d3/d3-foo/releases/latest).

## API Reference


<a href="#iconarray" name="iconarray">#</a> <b>iconarray</b>()
